library(shiny)
library(ggplot2)
library(dplyr)

data("life_expectancy_clean")

ui <- fluidPage(
  titlePanel("Life Expectancy Analysis"),
  sidebarLayout(
    sidebarPanel(
      sliderInput("year", "Select Year:", min = 1950, max = 2021, value = 2021),
      selectInput("country", "Select Country:", choices = unique(life_expectancy_clean$Entity))
    ),
    mainPanel(
      plotOutput("lifePlot")
    )
  )
)

server <- function(input, output) {
  output$lifePlot <- renderPlot({

    filtered_data <- life_expectancy_clean %>%
      filter(Year <= input$year & Entity == input$country & !is.na(LifeExpectancy))


    if (nrow(filtered_data) == 0) {
      plot(1, 1, type = "n", xlab = "", ylab = "", main = "No data for selected year")
      return()
    }


    ggplot(filtered_data, aes(x = Year, y = LifeExpectancy)) +
      geom_line(color = "steelblue", size = 1.2) +
      geom_point(color = "darkblue", size = 2) +
      labs(title = paste("Life Expectancy in", input$country, "up to", input$year),
           x = "Year",
           y = "Life Expectancy (Years)") +
      theme_light(base_size = 15) +
      theme(
        plot.title = element_text(face = "bold", hjust = 0.5, size = 18),
        axis.text.x = element_text(size = 12),
        axis.text.y = element_text(size = 12),
        axis.title = element_text(size = 14),
        plot.margin = unit(c(0.5, 0.5, 0.1, 0.5), "cm")
      )
  })
}

shinyApp(ui = ui, server = server)
