
# assignment-4-packages-and-shiny-apps-lihsuanchung

<!-- badges: start -->
<!-- badges: end -->

This is a R package for the ETC5523 assignment, which includes data analysis and a Shiny App designed to explore the data.

You can install this package using the following command:
remotes::install_github("ETC5523-2024/assignment-4-packages-and-shiny-apps-lihsuanchung")


To run the Shiny app, simply use the following command after installation:

library(assignment4lihsuan)
run_my_app()
